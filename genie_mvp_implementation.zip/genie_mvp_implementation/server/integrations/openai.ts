import { Configuration, OpenAIApi, ChatCompletionRequestMessage, ChatCompletionTool } from 'openai';

/**
 * OpenAI integration wrapper.
 *
 * Exposes a helper to call the OpenAI Responses API with the system
 * prompt and optional tool definitions. You may extend this file to
 * support streaming responses or to configure logging and retries.
 */

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});

const openai = new OpenAIApi(configuration);

export interface CompletionParams {
  messages: ChatCompletionRequestMessage[];
  tools?: ChatCompletionTool[];
  model?: string;
}

export async function callOpenAI({ messages, tools = [], model = 'gpt-4o' }: CompletionParams) {
  // Note: function calling is available via the tools parameter. This call
  // returns the full completion. For streaming, use createChatCompletion
  // with a stream flag and iterate through the chunks.
  const response = await openai.createChatCompletion({
    model,
    messages,
    tools,
    temperature: 0.2
  });
  return response.data;
}