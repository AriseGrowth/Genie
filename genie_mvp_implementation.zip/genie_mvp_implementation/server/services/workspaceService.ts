import { supabase } from '../integrations/supabase';
import { Workspace, WorkspaceKind } from '../../types';

/**
 * WorkspaceService
 *
 * Handles resolution and validation of workspaces. For the MVP we
 * assume that each user has exactly two workspaces (personal and
 * business). In a real implementation you would query the database.
 */

export async function resolveWorkspace(userId: string, workspaceKind: WorkspaceKind): Promise<Workspace> {
  // TODO: query supabase for the workspace by kind. For now return a
  // placeholder with deterministic id.
  return {
    id: `${userId}-${workspaceKind}`,
    kind: workspaceKind,
    name: workspaceKind.charAt(0).toUpperCase() + workspaceKind.slice(1)
  };
}

export async function assertWorkspaceAccess(userId: string, workspaceId: string): Promise<void> {
  // TODO: verify that the user has access to the workspace. Throw if not.
  return;
}