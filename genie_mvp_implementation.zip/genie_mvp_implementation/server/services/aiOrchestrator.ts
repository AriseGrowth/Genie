import { SYSTEM_PROMPT } from '../prompts/systemPrompt';
import { TOOL_DEFINITIONS, ToolDefinition } from '../prompts/toolDefinitions';
import { callOpenAI } from '../integrations/openai';
import { buildTodayBrief } from './todayBriefService';
import { createDraft as createEmailDraft, requestSend as requestDraftSend } from './draftService';
import { createTask } from './taskService';
import { summariseMeetingText } from './meetingService';
import { createApproval } from './approvalService';

/**
 * AI Orchestrator
 *
 * Accepts a user message, attaches system context and sends it to
 * OpenAI. If the model returns a tool call, this function invokes
 * the corresponding service and returns the tool result. Otherwise it
 * returns the assistant\'s plain response. This is a simplified
 * orchestrator; you may extend it to support streaming or multi-step
 * tool calls.
 */

export interface OrchestratorInput {
  userId: string;
  workspaceKind: 'personal' | 'business';
  conversationId?: string;
  message: string;
}

export async function orchestrate({ userId, workspaceKind, conversationId, message }: OrchestratorInput) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: message }
  ];
  // Map our tool definitions to OpenAI format
  const tools = TOOL_DEFINITIONS.map(def => ({
    type: 'function' as const,
    function: {
      name: def.name,
      description: def.description,
      parameters: def.parameters
    }
  }));

  const response = await callOpenAI({ messages, tools });
  const choice = response.choices[0];
  const assistantMessage = choice.message;

  // If the assistant returned a tool call, the content will be undefined and
  // the tool call information appears in the tool_calls array.
  if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
    const call = assistantMessage.tool_calls[0];
    const name = call.function.name;
    const args = JSON.parse(call.function.arguments || '{}');
    let result: any;
    switch (name) {
      case 'get_today_brief':
        result = await buildTodayBrief(userId, args.workspace);
        break;
      case 'create_email_draft':
        result = await createEmailDraft(userId, `${userId}-${args.workspace}`, {
          to: args.to,
          cc: args.cc ?? [],
          bcc: args.bcc ?? [],
          subject: args.subject,
          body: args.body
        });
        break;
      case 'create_task':
        result = await createTask(userId, `${userId}-${args.workspace}`, {
          title: args.title,
          notes: args.notes,
          dueAt: args.due_at,
          priority: args.priority,
          source: 'assistant'
        });
        break;
      case 'summarize_meeting_text':
        result = await summariseMeetingText(userId, `${userId}-${args.workspace}`, args.meeting_text);
        break;
      case 'request_approval':
        result = await createApproval({
          userId,
          workspaceId: `${userId}-${args.workspace}`,
          actionType: args.action_type,
          payload: args.payload
        });
        break;
      default:
        throw new Error(`Unsupported tool: ${name}`);
    }
    // Return the tool result to the client; the client can then render the card
    return {
      type: 'tool',
      name,
      result
    };
  }

  // Otherwise return the assistant response
  return {
    type: 'assistant',
    content: assistantMessage.content
  };
}