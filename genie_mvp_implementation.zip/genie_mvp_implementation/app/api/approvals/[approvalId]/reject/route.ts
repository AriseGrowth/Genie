import { NextRequest, NextResponse } from 'next/server';
import { reject } from '../../../../../../server/services/approvalService';

/**
 * POST /api/approvals/:approvalId/reject
 *
 * Rejects an approval request. Expects JSON body with userId. Returns
 * the updated approval.
 */

export async function POST(req: NextRequest, { params }: { params: { approvalId: string } }) {
  const { approvalId } = params;
  const body = await req.json();
  const { userId } = body;
  if (!userId || !approvalId) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const approval = await reject(approvalId, userId);
    return NextResponse.json(approval, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}