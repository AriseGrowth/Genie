import { NextRequest, NextResponse } from 'next/server';
import { approve } from '../../../../../../server/services/approvalService';

/**
 * POST /api/approvals/:approvalId/approve
 *
 * Approves an approval request and executes the associated action. Expects
 * JSON body with userId. Returns the updated approval and execution result.
 */

export async function POST(req: NextRequest, { params }: { params: { approvalId: string } }) {
  const { approvalId } = params;
  const body = await req.json();
  const { userId } = body;
  if (!userId || !approvalId) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const result = await approve(approvalId, userId);
    return NextResponse.json(result, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}