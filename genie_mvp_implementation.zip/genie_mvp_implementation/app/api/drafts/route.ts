import { NextRequest, NextResponse } from 'next/server';
import { createDraft } from '../../../server/services/draftService';

/**
 * POST /api/drafts
 *
 * Creates a new email draft. Expects body with userId, workspaceKind,
 * to, cc, bcc, subject and body. Returns the created draft. Does not send.
 */

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { userId, workspaceKind, to, cc = [], bcc = [], subject, body: emailBody } = body;
  if (!userId || !workspaceKind || !to || !subject || !emailBody) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const draft = await createDraft(userId, `${userId}-${workspaceKind}`, {
      to,
      cc,
      bcc,
      subject,
      body: emailBody
    });
    return NextResponse.json(draft, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}