import { NextRequest, NextResponse } from 'next/server';
import { requestSend } from '../../../../../server/services/draftService';

/**
 * POST /api/drafts/:draftId/request-send
 *
 * Creates an approval request for sending the draft. Expects body with
 * userId and workspaceKind. Returns the created approval.
 */

export async function POST(req: NextRequest, { params }: { params: { draftId: string } }) {
  const { draftId } = params;
  const body = await req.json();
  const { userId, workspaceKind } = body;
  if (!userId || !workspaceKind || !draftId) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const approval = await requestSend(userId, `${userId}-${workspaceKind}`, draftId);
    return NextResponse.json(approval, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}