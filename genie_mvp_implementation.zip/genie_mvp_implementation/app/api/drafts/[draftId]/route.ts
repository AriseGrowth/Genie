import { NextRequest, NextResponse } from 'next/server';
import { updateDraft } from '../../../../server/services/draftService';

/**
 * PATCH /api/drafts/:draftId
 *
 * Updates the subject or body of a draft. Expects JSON body with
 * userId and optional subject/body. Returns the updated draft.
 */

export async function PATCH(req: NextRequest, { params }: { params: { draftId: string } }) {
  const { draftId } = params;
  const body = await req.json();
  const { userId, subject, body: emailBody, status } = body;
  if (!userId || !draftId) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const draft = await updateDraft(userId, draftId, { subject, body: emailBody, status });
    return NextResponse.json(draft, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}