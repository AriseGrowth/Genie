import { NextRequest, NextResponse } from 'next/server';
import { completeTask } from '../../../../../server/services/taskService';

/**
 * POST /api/tasks/:taskId/complete
 *
 * Marks a task as done. Expects JSON body with userId.
 */
export async function POST(req: NextRequest, { params }: { params: { taskId: string } }) {
  const { taskId } = params;
  const body = await req.json();
  const { userId } = body;
  if (!userId || !taskId) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const task = await completeTask(taskId);
    return NextResponse.json(task, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}