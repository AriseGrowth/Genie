import { NextRequest, NextResponse } from 'next/server';
import { createTask, listTasks } from '../../../server/services/taskService';

/**
 * GET /api/tasks
 *
 * Lists tasks for the active workspace. Expects query parameters
 * userId, workspaceKind, and optional status.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get('userId');
  const workspaceKind = searchParams.get('workspaceKind');
  const status = searchParams.get('status') || 'open';
  if (!userId || !workspaceKind) {
    return NextResponse.json({ error: 'Missing userId or workspaceKind' }, { status: 400 });
  }
  try {
    const tasks = await listTasks(`${userId}-${workspaceKind}`, status);
    return NextResponse.json({ tasks }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

/**
 * POST /api/tasks
 *
 * Creates a new task. Expects body with userId, workspaceKind,
 * title, optional notes, dueAt and priority.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { userId, workspaceKind, title, notes, dueAt, priority } = body;
  if (!userId || !workspaceKind || !title) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const task = await createTask(userId, `${userId}-${workspaceKind}`, {
      title,
      notes,
      dueAt,
      priority
    });
    return NextResponse.json(task, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}