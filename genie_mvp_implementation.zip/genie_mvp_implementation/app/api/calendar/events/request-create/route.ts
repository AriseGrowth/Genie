import { NextRequest, NextResponse } from 'next/server';
import { createApproval } from '../../../../../server/services/approvalService';

/**
 * POST /api/calendar/events/request-create
 *
 * Creates an approval request for creating a calendar event. Expects
 * JSON body with userId, workspaceKind, and event details. Returns
 * the approval record.
 */
export async function POST(req: NextRequest) {
  const { userId, workspaceKind, title, startTime, endTime, attendees = [], notes, location } = await req.json();
  if (!userId || !workspaceKind || !title || !startTime || !endTime) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const approval = await createApproval({
      userId,
      workspaceId: `${userId}-${workspaceKind}`,
      actionType: 'create_calendar_event',
      payload: { title, startTime, endTime, attendees, notes, location }
    });
    return NextResponse.json(approval, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}