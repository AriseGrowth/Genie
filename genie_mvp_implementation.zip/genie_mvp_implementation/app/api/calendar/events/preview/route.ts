import { NextRequest, NextResponse } from 'next/server';
import { previewEvent } from '../../../../../server/integrations/googleCalendar';

/**
 * POST /api/calendar/events/preview
 *
 * Returns a preview of a calendar event without creating it. Expects
 * JSON body with workspaceKind, title, startTime, endTime and
 * optional attendees/notes/location.
 */
export async function POST(req: NextRequest) {
  const { workspaceKind, title, startTime, endTime, attendees = [], notes, location } = await req.json();
  if (!workspaceKind || !title || !startTime || !endTime) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const preview = await previewEvent({ title, startTime, endTime, attendees, notes, location });
    return NextResponse.json({ preview }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}