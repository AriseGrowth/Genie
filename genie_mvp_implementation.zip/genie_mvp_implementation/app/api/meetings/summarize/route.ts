import { NextRequest, NextResponse } from 'next/server';
import { summariseMeetingText } from '../../../../server/services/meetingService';

/**
 * POST /api/meetings/summarize
 *
 * Summarises meeting text and returns summary, decisions and action items.
 * Expects body with userId, workspaceKind and meetingText.
 */

export async function POST(req: NextRequest) {
  const { userId, workspaceKind, meetingText } = await req.json();
  if (!userId || !workspaceKind || !meetingText) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const summary = await summariseMeetingText(userId, `${userId}-${workspaceKind}`, meetingText);
    return NextResponse.json(summary, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}