import { NextRequest, NextResponse } from 'next/server';
import { orchestrate } from '../../../server/services/aiOrchestrator';

/**
 * POST /api/chat/respond
 *
 * Accepts a user message and returns an assistant response or
 * tool result. Expects JSON body with userId, workspaceKind and
 * message. In a real application you would derive the user from
 * the session and validate inputs via a schema.
 */

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { userId, workspaceKind, message } = body;
  if (!userId || !workspaceKind || !message) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
  try {
    const result = await orchestrate({ userId, workspaceKind, message });
    return NextResponse.json(result, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}