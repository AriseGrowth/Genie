import { NextRequest, NextResponse } from 'next/server';
import { buildTodayBrief } from '../../../server/services/todayBriefService';

/**
 * GET /api/today
 *
 * Returns the TodayBrief for the requested workspace. Expects
 * query parameters userId and workspaceKind. In a real application
 * userId would be derived from the session.
 */

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get('userId');
  const workspaceKind = searchParams.get('workspaceKind');
  if (!userId || !workspaceKind) {
    return NextResponse.json({ error: 'Missing userId or workspaceKind' }, { status: 400 });
  }
  try {
    const brief = await buildTodayBrief(userId, workspaceKind as any);
    return NextResponse.json(brief, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}